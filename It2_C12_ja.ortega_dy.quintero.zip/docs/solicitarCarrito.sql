INSERT INTO A_CARRITO (id, idSucursal, idCliente, estado) values (20000, 6, 1018513457, 'EN_USO');
